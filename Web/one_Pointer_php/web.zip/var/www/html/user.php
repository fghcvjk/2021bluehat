<?php
class User{
	public $count;
}
?>